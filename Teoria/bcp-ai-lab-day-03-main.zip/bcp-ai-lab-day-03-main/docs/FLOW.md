# Flujo del Día 3

## Mapa conceptual de la agenda

```mermaid
flowchart LR
    S1["S1 - OpenSpec / Spec Kit + Constitution"]
    S2["S2 - Specify -> Plan -> Tasks -> Validate"]
    S3["S3 - model + tools + context + loop"]
    S4["S4 - routing + evaluator + HITL"]

    S1 --> S2
    S3 --> S4
    S2 --> I[ReqFlow - cambio guiado]
    S4 --> I
```

SDD y fundamentos de agentes convergen en el mismo cambio controlado sobre ReqFlow.

## Producto y trazabilidad

```mermaid
flowchart TB
    P[ReqFlow - GitHub Project]
    FE[workshop-login-frontend]
    BE[workshop-auth-backend]
    API[workshop-requirements-api]

    FE --> P
    BE --> P
    API --> P
```

El Project representa al producto. Los Issues permanecen en el repositorio donde se implementan.

## Fundamentos del agente

```mermaid
flowchart LR
    M[Model] --> A[Agent]
    I[Instructions] --> A
    C[Context] --> A
    T[Tools / MCP] --> A
    A --> O[Observe result]
    O --> A
    A --> E[Evidence]
```

El loop continúa mientras exista una acción permitida y evidencia que procesar; un gate puede detenerlo.

## Routing + evaluator + HITL

```mermaid
flowchart LR
    U[Participante] --> R{Routing}
    R --> PO[PM/PO]
    R --> DI[Discovery]
    R --> AR[Architect]
    R --> DE[Developer]

    PO --> EV[Evaluator / evidencia]
    DI --> EV
    AR --> EV
    DE --> EV

    EV --> H{HITL}
    H -->|Avanzar| R
    H -->|Corregir| R
    H -->|Cerrar| F[Resultado aceptado]
```

En el taller el routing es explícito: el participante selecciona el rol adecuado.

## Specify -> Plan -> Tasks -> Validate con OpenSpec

```mermaid
flowchart LR
    SP[Specify] --> PS[proposal + specs]
    PL[Plan] --> D[design]
    TA[Tasks] --> T[tasks.md]
    VA[Validate] --> V[openspec validate + tests + gates]

    PS --> D
    D --> T
    T --> V
    V --> AP[apply / implementación]
```

## OpenSpec + GitHub

```mermaid
flowchart LR
    O[OpenSpec] --> P1[proposal.md]
    O --> S1[specs/]
    O --> D1[design.md]
    O --> T1[tasks.md]

    G[GitHub] --> I[Issue]
    G --> PJ[Project]
    G --> B[Branch]
    G --> PR[Pull Request]
    G --> C[Checks]

    I -. alcance y trazabilidad .-> O
    T1 -. checklist de implementación .-> B
```

Durante el taller `tasks.md` y GitHub Issue conviven. El Issue representa el trabajo del producto; `tasks.md` descompone el cambio OpenSpec.

## Flujo SDD guiado

```mermaid
flowchart TD
    Existing[Sistema existente] --> Discovery[Discovery multi-repo]
    Discovery --> Finding[Hallazgo con evidencia]
    Finding --> Gate0{HITL: revisar hallazgo}
    Gate0 -->|Aprobado| Issue[GitHub Issue priorizado en Project]
    Gate0 -->|Descartar / ampliar evidencia| Discovery

    Issue --> Branch[Rama del Issue]
    Branch --> Proposal[OpenSpec proposal + specs]
    Proposal --> Gate1{HITL: revisar Specify}
    Gate1 -->|Aprobado| Design[OpenSpec design]
    Gate1 -->|Ajustar| Proposal

    Design --> Gate2{HITL: revisar Plan}
    Gate2 -->|Aprobado| Tasks[OpenSpec tasks]
    Gate2 -->|Ajustar| Design

    Tasks --> Gate3{HITL: revisar Tasks}
    Gate3 -->|Aprobado| Characterization[Characterization tests]
    Gate3 -->|Ajustar| Tasks

    Characterization --> Apply[OpenSpec apply]
    Apply --> Change[Cambio incremental]
    Change --> Tests[Tests / evaluator]
    Tests --> FinalPR[PR final rama del Issue -> main]
    FinalPR --> Checks[GitHub checks]
    Checks --> DoD[Definition of Done]
    DoD --> Gate4{HITL: aceptar cierre}
```

## Personalización opcional posterior

```mermaid
flowchart LR
    Standard[spec-driven estándar] --> Full[proposal -> specs -> design -> tasks -> apply]
    Full --> Learn[Recorrido principal del Día 3]
    Learn --> Custom[Ejemplo opcional: schema reqflow-github]
    Custom --> Issues[proposal -> specs -> design -> apply + GitHub Issues]
```

El schema personalizado se presenta al final como alternativa para equipos que prefieran evitar doble tracking. No altera la funcionalidad de ReqFlow.
