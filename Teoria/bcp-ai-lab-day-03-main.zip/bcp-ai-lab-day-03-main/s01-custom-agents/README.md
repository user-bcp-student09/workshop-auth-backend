# Módulo práctico - Custom Agents sobre ReqFlow

> Este módulo aporta principalmente a **S3 - Fundamentos: model + tools + context + loop** y prepara **S4 - routing, evaluator, HITL**. No sustituye el nombre oficial de esas sesiones.

## Objetivo

Transformar el modo Agent genérico de VS Code en roles especializados con responsabilidades y límites explícitos.

Antes de enrutar trabajo entre varios roles, observa primero qué hace que **un solo agente** sea distinto de un prompt aislado:

```text
model
+ instructions persistentes
+ context
+ tools permitidas
+ loop de ejecución
= agent
```

## Agents del caso

```text
PM/PO
Discovery
Architect
Developer
```

Estos perfiles se reutilizarán después para mostrar routing explícito.

## Preparación del entorno

Vienes del Día 2: `reqflow-workspace/.vscode/mcp.json` ya existe. **Consérvalo y ajústalo**: mantén `github-official`, agrega `projects` a `X-MCP-Toolsets` y quita `github-local` (MCP local, puerto 8081) y `github-official-readonly`, que hoy no se usan.

Puedes partir de:

```text
templates/mcp/mcp.json.example
```

El servidor debe llamarse:

```text
github-official
```

En el Día 3 utilizaremos además el toolset `projects`.

Después de dejar limpio el archivo, verifica en VS Code que `github-official` pueda iniciarse y aparezca en estado **Started**.

> En la primera prueba de límites no es necesario invocar MCP. El objetivo inicial es aislar instructions + context y observar el comportamiento de un single-agent.

## Preparación de los Agents

Copia los templates desde:

```text
bcp-ai-lab-day-03/templates/agents/
```

(el lab está al lado del workspace) hacia `reqflow-workspace/.github/agents/` (en `s04` paso 0 se copian también a `workshop-requirements-api`).

Resultado esperado:

```text
.github/
└─ agents/
   ├─ pm-po.agent.md
   ├─ discovery.agent.md
   ├─ architect.agent.md
   └─ developer.agent.md
```

## Parte 1 - Responsabilidades

### PM/PO

Trabaja sobre necesidad, criterios de aceptación, prioridades y trazabilidad.

No debe refactorizar código, decidir arquitectura ni inventar hallazgos técnicos.

### Discovery

Comprende el sistema antes de modificarlo y produce hallazgos con evidencia.

No debe arreglar automáticamente lo que encuentra.

### Architect

Convierte una necesidad o hallazgo aprobado en límites técnicos claros.

No debe implementar el cambio funcional.

### Developer

Implementa únicamente trabajo aprobado y respeta specs, decisiones, contratos y Definition of Done.

No debe ampliar alcance por su cuenta.

## Parte 2 - Probar un agente y sus límites

Estas pruebas se realizan en GitHub Copilot Chat dentro de VS Code. Selecciona un solo Custom Agent y observa cómo sus instrucciones persistentes condicionan la respuesta.

Selecciona `Discovery`:

```text
Esta es únicamente una prueba de los límites de tu rol.
No leas archivos, no busques en el workspace y no uses MCP ni ninguna otra tool.

Supón que durante un análisis encuentras un problema importante en ReqFlow.
¿Puedes corregirlo directamente?
Explica qué deberías hacer según tu responsabilidad antes de que alguien modifique código.
```

Selecciona `PM/PO`:

```text
Esta es únicamente una prueba de los límites de tu rol.
No leas archivos y no uses ninguna tool.

Supón que se detectó deuda en la capa de persistencia de ReqFlow.
¿Debes decidir y ejecutar tú mismo el refactor técnico?
Explica qué te corresponde hacer y a qué rol debería pasar la decisión técnica.
```

Selecciona `Architect`:

```text
Esta es únicamente una prueba de los límites de tu rol.
No leas archivos y no uses ninguna tool.

Supón que recibes un hallazgo técnico ya confirmado.
¿Debes implementar directamente el cambio en código?
Explica cuál es tu responsabilidad y cuándo debe intervenir Developer.
```

Selecciona `Developer`:

```text
Esta es únicamente una prueba de los límites de tu rol.
No leas archivos y no uses ninguna tool.

Te piden mejorar todo ReqFlow sin issue, spec ni alcance aprobado.
¿Debes empezar a modificar código?
Explica qué información necesitas antes de implementar.
```

## De single-agent a routing

Una vez comprendido cada perfil de forma aislada, S4 reutiliza los mismos roles como destinos de routing:

```text
producto/alcance -> PM/PO
hallazgo         -> Discovery
diseño           -> Architect
implementación   -> Developer
```

El taller no requiere un router autónomo: seleccionar deliberadamente el Agent correcto ya permite observar el patrón y discutir sus reglas.

## Criterio de salida

El participante puede explicar:

```text
Agent != prompt largo
Agent = model + instrucciones + contexto + tools + loop
```

y puede justificar por qué una tarea debe enrutarse a un rol y no a otro.
