# Paso 1 - Crear los Skills

## Objetivo

Instalar en el workspace los procedimientos reutilizables que utilizarán los Custom Agents durante el Día 3.

## 1.1 Ubicación de los Skills

Los templates se encuentran en:

```text
templates/skills/
```

Copia **cada carpeta completa** hacia:

```text
reqflow-workspace/.github/skills/
```

No copies únicamente el archivo `SKILL.md`. La carpeta completa representa el Skill y puede contener en el futuro ejemplos, scripts u otros recursos auxiliares.

## 1.2 Skills a copiar

```text
discovery-analysis/
spec-writing/
architecture-decision/
issue-implementation/
reqflow-definition-of-done/
```

Cada carpeta contiene su propio `SKILL.md`.

## 1.3 Resultado esperado

Después de copiar los Skills, el workspace debe quedar aproximadamente así:

```text
.github/
├─ agents/
│  ├─ pm-po.agent.md
│  ├─ discovery.agent.md
│  ├─ architect.agent.md
│  └─ developer.agent.md
│
└─ skills/
   ├─ discovery-analysis/
   │  └─ SKILL.md
   ├─ spec-writing/
   │  └─ SKILL.md
   ├─ architecture-decision/
   │  └─ SKILL.md
   ├─ issue-implementation/
   │  └─ SKILL.md
   └─ reqflow-definition-of-done/
      └─ SKILL.md
```

Los Agents y Skills quedan versionados junto con el workspace/proyecto y pueden evolucionar de forma independiente.

## 1.4 Qué revisar

Abre cada `SKILL.md` y localiza:

- cuándo debería aplicarse;
- qué entradas necesita;
- qué procedimiento sigue;
- qué salida produce;
- qué acciones evita realizar.

## Regla de diseño

Un Skill describe **cómo ejecutar una práctica reusable**. No debe convertirse en una segunda definición del rol.

Evita duplicar en un Skill instrucciones como:

```text
"eres el PM/PO"
"eres el Developer"
```

Eso pertenece al Custom Agent.

## Criterio de salida

Los cinco Skills están instalados bajo `.github/skills/` y el participante puede distinguir entre:

```text
Agent = responsabilidad persistente
Skill = procedimiento reusable
```

Continúa con [Paso 2 - Validar Skills y responsabilidades](STEP_2_VALIDATE_SKILLS.md).
