# Paso 2 - Validar Skills y responsabilidades

## Objetivo

Comprobar que los Skills aportan procedimientos reutilizables sin borrar los límites del Agent seleccionado.

En este paso **todavía no haremos Discovery real sobre los repositorios de ReqFlow**. Eso comenzará en la S3, cuando el workspace multi-repo esté preparado.

Para evitar que Copilot empiece a buscar archivos, repositorios o contexto que todavía no corresponde, las pruebas de este paso usan escenarios controlados y no requieren MCP ni inspección del workspace.

## 2.1 Discovery + discovery-analysis

Selecciona `Discovery` y ejecuta:

```text
Esta es una prueba controlada del Skill discovery-analysis.
No leas archivos, no busques en el workspace y no uses MCP ni otras tools.

Supón que durante una revisión se observa que un endpoint construye una consulta SQL concatenando directamente un valor recibido por parámetro.

Aplica el procedimiento de discovery-analysis y presenta:
- observación;
- evidencia disponible;
- impacto potencial;
- prioridad sugerida;
- contrato potencialmente afectado;
- forma de validación.

No propongas todavía una implementación.
```

Resultado esperado: el Agent organiza el hallazgo siguiendo un procedimiento de Discovery y mantiene separados hechos, hipótesis y validación pendiente.

## 2.2 PM/PO + spec-writing

Selecciona `PM/PO` y ejecuta:

```text
Esta es una prueba controlada del Skill spec-writing.
No leas archivos y no uses MCP ni otras tools.

Considera aprobado este hallazgo:
"La creación de tareas debe mantener el contrato HTTP actual, pero la validación de entrada debe impedir datos inválidos antes de llegar a persistencia."

Conviértelo en una spec de cambio verificable.
No diseñes la implementación técnica.
```

Resultado esperado: la salida distingue al menos comportamiento actual/protegido, cambio solicitado, alcance, fuera de alcance y criterios verificables.

## 2.3 Architect + architecture-decision

Selecciona `Architect` y ejecuta:

```text
Esta es una prueba controlada del Skill architecture-decision.
No leas archivos y no uses MCP ni otras tools.

Supón que existe una spec aprobada que exige validar la entrada de creación de tareas sin modificar el contrato HTTP existente.

Analiza:
- impacto técnico esperado;
- contrato que debe protegerse;
- responsabilidades que conviene separar;
- decisiones que deberían registrarse antes de implementar.

No escribas código.
```

Resultado esperado: el Agent razona sobre límites y decisiones técnicas sin convertirse en implementador.

## 2.4 Developer + issue-implementation

Selecciona `Developer` y ejecuta:

```text
Esta es una prueba controlada del Skill issue-implementation.
No leas archivos y no uses MCP ni otras tools.
No implementes código real.

Supón que recibes un issue aprobado con:
- alcance: validar la entrada al crear tareas;
- contrato protegido: POST /api/tasks;
- restricción: no cambiar el formato de request ni response;
- aceptación: entradas inválidas deben rechazarse de forma controlada.

Describe el plan de implementación que seguirías aplicando el Skill issue-implementation y qué evidencias exigirías antes de considerar terminado el trabajo.
```

Resultado esperado: el Developer mantiene el scope acotado, incluye pruebas y evidencia, y no amplía el cambio por iniciativa propia.

## 2.5 Definition of Done transversal

Selecciona cualquiera de los Agents y ejecuta:

```text
Esta es una prueba controlada del Skill reqflow-definition-of-done.
No uses tools.

Evalúa este estado hipotético:
- contrato HTTP preservado;
- build exitoso;
- pruebas unitarias ejecutadas;
- cobertura todavía no medida;
- revisión de seguridad todavía no realizada;
- PR todavía no creado.

Clasifica cada criterio de Definition of Done según la evidencia realmente disponible.
No marques como cumplido aquello que todavía no fue verificado.
```

Resultado esperado: el Skill no inventa evidencia y distingue correctamente entre cumplido, pendiente, falta evidencia o no aplica.

## 2.6 Qué estamos validando

Estas pruebas buscan demostrar:

```text
Agent
  = responsabilidad y límites

Skill
  = procedimiento reutilizable

Caso controlado
  = contexto mínimo para observar el comportamiento
```

Todavía **no** estamos evaluando si el Agent puede descubrir correctamente problemas reales en ReqFlow.

Eso se hará en la S3 con los tres repositorios disponibles:

```text
workshop-login-frontend
workshop-auth-backend
workshop-requirements-api
```

## Criterio de salida

Puede demostrarse que:

```text
Agent conserva responsabilidad
+
Skill aporta procedimiento
+
la evidencia real sigue siendo necesaria
```

El participante está listo para aplicar Agents y Skills sobre el producto real en la siguiente sesión.
