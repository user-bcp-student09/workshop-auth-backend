# Módulo práctico - ReqFlow como producto multi-repositorio

> Este módulo hace concretos varios fundamentos de **S3 - model + tools + context + loop** mediante un workspace multi-repo y GitHub MCP, y prepara el escenario de routing/HITL usado en S4.

## Objetivo

Configurar el entorno completo de ReqFlow antes de implementar cambios:

```text
3 repositorios de trabajo independientes
+
1 workspace de producto
+
GitHub MCP oficial
+
1 GitHub Project
+
issues distribuidos
```

## Repositorios del participante (ya creados en el Día 1)

En este día se trabaja sobre el workspace del participante en `./reqflow-workspace/`.
Los repositorios se referencian por su ubicación local y por su repo remoto (sin `-template`).

Ubicación local esperada:

```text
./workshop-login-frontend
./workshop-auth-backend
./workshop-requirements-api
```

Cada participante ya publicó el Día 1 sus copias independientes bajo su owner (hoy no se vuelven a crear):

```text
<OWNER>/workshop-login-frontend
<OWNER>/workshop-auth-backend
<OWNER>/workshop-requirements-api
```

Las plantillas del trainer solo se referencian explícitamente cuando corresponda, por ejemplo:

```text
https://github.com/NTTData-Academy/workshop-login-frontend-template.git
```

Los tres forman un producto; ninguno representa por sí solo a ReqFlow.

## Contexto multi-repo

Abre VS Code desde:

```text
reqflow-workspace/
```

Aquí **sí** es intencional que Discovery pueda comprender los tres repositorios porque estamos trabajando con contexto de producto.

Más adelante, cuando el flujo SDD se concentre en un único Issue de `workshop-requirements-api`, los prompts limitarán explícitamente lecturas, comandos y cambios a ese repositorio.

## GitHub MCP oficial

El MCP representa la capa de tools externas del agente:

```text
Agent
-> GitHub MCP
-> repos / issues / projects / pull requests
```

Se habilita explícitamente `projects`:

```json
{
  "servers": {
    "github-official": {
      "type": "http",
      "url": "https://api.githubcopilot.com/mcp/",
      "headers": {
        "X-MCP-Toolsets": "context,repos,issues,pull_requests,projects,users"
      }
    }
  }
}
```

No continúes con operaciones de escritura hasta haber demostrado una lectura real de repositorios y Projects mediante `github-official`.

## Resultado esperado

```text
GitHub Project: ReqFlow
  |
  +-- issue de Frontend ------> <OWNER>/workshop-login-frontend
  +-- issue de Backend -------> <OWNER>/workshop-auth-backend
  +-- issue de API -----------> <OWNER>/workshop-requirements-api
```

Cada escritura debe dejar evidencia verificable en GitHub. Una respuesta del Agent diciendo "hecho" no sustituye la verificación del recurso creado.

## Secuencia

Contexto del producto (contratos, restricciones, DoD): [CASE.md](CASE.md).

1. [Verificar el workspace multi-repo del Día 1](STEP_1_WORKSPACE.md)
2. [Configurar GitHub MCP oficial](STEP_2_MCP.md)
3. [Reutilizar el GitHub Project ReqFlow del Día 2](STEP_3_PROJECT.md)
4. [Discovery sobre HALLAZGOS.md y completar el backlog](STEP_4_DISCOVERY_BACKLOG.md)

## Regla pedagógica

```text
hallazgo
 -> evidencia
 -> revisión humana
 -> Issue
 -> verificar Issue real
 -> agregar a Project
 -> verificar item real
```

La IA ayuda a descubrir y estructurar; no decide por sí sola qué trabajo compromete el equipo.

## Criterio de salida

El participante puede demostrar que:

- posee tres repositorios de trabajo propios;
- VS Code está abierto sobre el workspace de producto;
- `github-official` está conectado;
- las tools de Projects funcionan realmente;
- existe un Project ReqFlow;
- los Issues creados existen en el repositorio correcto;
- esos Issues aparecen realmente como items del Project;
- los hallazgos fueron revisados antes de convertirse en backlog comprometido.
