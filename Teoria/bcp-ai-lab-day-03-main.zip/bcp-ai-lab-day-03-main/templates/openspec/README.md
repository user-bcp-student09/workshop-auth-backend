# Referencia de configuración OpenSpec para ReqFlow

Esta carpeta acompaña el Día 3.

## Recorrido principal

El laboratorio usa el schema estándar:

```text
spec-driven
```

con el flujo completo:

```text
proposal -> specs -> design -> tasks -> apply
```

Después de ejecutar `openspec init`, conserva el `openspec/config.yaml` generado y agrega el contexto/reglas de ReqFlow sin borrar propiedades creadas por OpenSpec para GitHub Copilot.

Usa `config.yaml.example` como referencia de contenido, no como archivo para reemplazar ciegamente el generado.

## GitHub durante el recorrido

GitHub sigue cumpliendo funciones operativas:

```text
Issue   = trabajo comprometido y trazabilidad
Project = prioridad y coordinación multi-repo
branch  = integración del Issue
PR      = revisión e integración
checks  = evidencia automática
```

`tasks.md` convive con el Issue y actúa como checklist interno del cambio OpenSpec.

## Personalización opcional posterior

La carpeta:

```text
schemas/reqflow-github/
```

contiene un ejemplo de schema personalizado que elimina `tasks.md` y delega el tracking en GitHub Issues.

Ese schema **no se instala ni se activa durante el recorrido principal**. Se revisa al final del día para demostrar que OpenSpec puede adaptarse a la forma de trabajo de un equipo sin cambiar la funcionalidad de la aplicación.
