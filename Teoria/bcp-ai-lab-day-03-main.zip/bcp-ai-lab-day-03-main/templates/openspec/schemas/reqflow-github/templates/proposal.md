## GitHub Issue

- Issue: #<NUMERO>
- Repositorio: <OWNER>/workshop-requirements-api

## Why

<!-- ¿Qué problema confirmado resuelve este cambio y por qué importa ahora? -->

## What Changes

<!-- Describe el cambio esperado sin entrar todavía en diseño técnico. -->

## Preserved Behavior

<!-- ¿Qué comportamiento/contrato existente debe seguir funcionando? -->

## Out of Scope

<!-- Explicita qué NO se resolverá en este cambio. -->

## Capabilities

### New Capabilities

<!-- Capacidades nuevas, si aplica. -->

### Modified Capabilities

<!-- Capacidades existentes cuyo comportamiento observable cambia. -->

## Impact

<!-- Repositorio, endpoints, consumidores o dependencias potencialmente afectados. -->
